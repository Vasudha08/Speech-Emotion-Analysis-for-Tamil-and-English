package com.example.med_vitals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()